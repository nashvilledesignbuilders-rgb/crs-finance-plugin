﻿export const CRS_API_URL  = "https://api.crsprovider.com";
export const CRS_API_KEY  = process.env.CRS_API_KEY!;
