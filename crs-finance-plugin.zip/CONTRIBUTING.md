﻿# Contributing

1. Fork & branch.
2. Follow code patterns in lib/.
3. Run 
pm run lint and tests.
4. Submit PR with clear description.
